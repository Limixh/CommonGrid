export function lower_bound() { return 0; }
